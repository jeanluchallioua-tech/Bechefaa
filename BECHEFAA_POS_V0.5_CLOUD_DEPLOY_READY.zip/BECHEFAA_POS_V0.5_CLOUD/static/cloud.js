
(() => {
  const MODE = location.pathname.replaceAll("/","").toLowerCase() || "caisse";
  const $ = (s) => document.querySelector(s);
  const $$ = (s) => [...document.querySelectorAll(s)];

  async function api(path, options={}) {
    const res = await fetch(path, {
      headers: {"Content-Type":"application/json", ...(options.headers||{})},
      ...options
    });
    if(!res.ok) throw new Error(await res.text());
    return res.status === 204 ? null : res.json();
  }

  async function refreshOrders() {
    try {
      const fresh = await api("/api/orders");
      if(Array.isArray(fresh)) {
        window.__cloudOrders = fresh;
        // Replace the local array used by the V0.4.5 frontend.
        if(typeof orders !== "undefined") {
          orders.length = 0;
          fresh.forEach(o => orders.push(o));
          if(typeof boards === "function") boards();
        }
      }
      document.body.classList.remove("cloud-offline");
    } catch(e) {
      document.body.classList.add("cloud-offline");
    }
  }

  async function refreshClients() {
    try {
      const fresh = await api("/api/clients");
      if(Array.isArray(fresh) && typeof clients !== "undefined") {
        clients.length = 0;
        fresh.forEach(c => clients.push(c));
        if(typeof rClients === "function") rClients();
      }
    } catch(e) {}
  }

  function modeUI() {
    const brand = $(".brand small");
    if(brand) brand.textContent = "POS V0.5 · " + MODE.toUpperCase();

    if(MODE === "cuisine") {
      $$(".nav").forEach(b => b.classList.add("hidden"));
      $$(".view").forEach(v => v.classList.add("hidden"));
      const k = $("#kitchen");
      if(k) k.classList.remove("hidden");
      document.body.classList.add("mode-kitchen");
    } else if(MODE === "salle") {
      const source = $$('.channel[data-ch="CAISSE"]')[0];
      if(source) source.textContent = "Salle";
      document.body.classList.add("mode-salle");
    } else {
      document.body.classList.add("mode-caisse");
    }
  }

  function installCloudHooks() {
    // Cloud create order: intercept the existing validate button after the base app has initialized.
    const validate = $("#validate");
    if(validate) {
      validate.addEventListener("click", async () => {
        setTimeout(async () => {
          try {
            // Base app has just created local order; sync the newest order.
            if(typeof orders !== "undefined" && orders[0]) {
              const o = {...orders[0]};
              if(MODE === "salle") o.source = "SALLE";
              await api("/api/orders", {method:"POST", body:JSON.stringify(o)});
              await refreshOrders();
            }
          } catch(e) {}
        }, 0);
      }, true);
    }

    const saveClient = $("#saveClient");
    if(saveClient) {
      saveClient.addEventListener("click", async () => {
        setTimeout(async () => {
          try {
            if(typeof clients !== "undefined" && clients[0]) {
              await api("/api/clients", {method:"POST", body:JSON.stringify(clients[0])});
              await refreshClients();
            }
          } catch(e) {}
        }, 0);
      }, true);
    }

    // Status buttons are re-rendered, so delegate.
    document.addEventListener("click", async (e) => {
      const b = e.target.closest("[data-m]");
      if(!b) return;
      const id = b.dataset.m;
      setTimeout(async () => {
        try {
          const o = typeof orders !== "undefined" ? orders.find(x => String(x.id) === String(id)) : null;
          if(o) await api(`/api/orders/${id}`, {method:"PATCH", body:JSON.stringify({status:o.status})});
          await refreshOrders();
        } catch(e) {}
      }, 0);
    }, true);
  }

  function enhanceKitchenChecks() {
    const root = $("#kitchenBoard");
    if(!root) return;
    root.querySelectorAll(".order").forEach(card => {
      const btn = card.querySelector("[data-m]");
      const orderId = btn?.dataset.m || card.dataset.orderId;
      if(!orderId) return;
      const order = typeof orders !== "undefined" ? orders.find(o => String(o.id) === String(orderId)) : null;
      if(!order) return;

      [...card.querySelectorAll("li")].forEach((li, i) => {
        if(li.querySelector(".cloud-kcheck")) return;
        const cb = document.createElement("input");
        cb.type = "checkbox";
        cb.className = "cloud-kcheck";
        cb.checked = !!order.items?.[i]?.prepared;
        li.prepend(cb);
        li.classList.toggle("kitchen-done", cb.checked);
        cb.addEventListener("change", async () => {
          li.classList.toggle("kitchen-done", cb.checked);
          try {
            await api(`/api/orders/${orderId}/items/${i}`, {
              method:"PATCH",
              body:JSON.stringify({prepared:cb.checked})
            });
            await refreshOrders();
          } catch(e) {}
        });
      });

      const checks = [...card.querySelectorAll(".cloud-kcheck")];
      if(checks.length) {
        let p = card.querySelector(".cloud-progress");
        if(!p) {
          p = document.createElement("div");
          p.className = "cloud-progress";
          card.appendChild(p);
        }
        const done = checks.filter(x => x.checked).length;
        p.textContent = done === checks.length
          ? `✓ COMMANDE PRÊTE · ${done}/${checks.length}`
          : `Préparation · ${done}/${checks.length}`;
        card.classList.toggle("kitchen-ready", done === checks.length);
      }
    });
  }

  const obs = new MutationObserver(() => enhanceKitchenChecks());

  window.addEventListener("load", async () => {
    modeUI();
    installCloudHooks();
    await Promise.all([refreshOrders(), refreshClients()]);
    enhanceKitchenChecks();
    const kb = $("#kitchenBoard");
    if(kb) obs.observe(kb, {childList:true, subtree:true});
    setInterval(refreshOrders, 1500);
  });
})();
