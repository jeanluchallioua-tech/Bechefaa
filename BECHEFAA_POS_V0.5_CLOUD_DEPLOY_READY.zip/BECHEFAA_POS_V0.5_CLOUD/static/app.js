document.addEventListener("DOMContentLoaded",()=>{
const $=x=>document.getElementById(x),euro=n=>n.toLocaleString("fr-FR",{style:"currency",currency:"EUR"});
let cat=window.CATEGORIES[0],ch="CAISSE",cart=[],sel=null,clients=JSON.parse(localStorage.getItem("b_clients043")||"[]"),orders=JSON.parse(localStorage.getItem("b_orders043")||"[]"),current=null,selections={};
const price=p=>["UBER EATS","DELIVEROO"].includes(ch)?+(p*1.15).toFixed(2):p;

/* Choix issus du catalogue Wix Restaurants BÉCHÉFAA */
const GROUPS={
 cuisson:{title:"Cuisson",required:false,max:1,choices:[["Bleu",0],["Saignant",0],["À point",0],["Bien cuit",0]]},
 pain:{title:"Choix du pain",required:true,max:1,choices:[["Baguette",0],["Tacos",0],["Pita",0],["Pain kebab",0],["Laffa",3],["Pita panée",3.5],["Tacos pané",3.5]]},
 sauces:{title:"Sauces",required:false,max:3,choices:[["Ketchup",0],["Mayonnaise",0],["Barbecue",0],["Harissa maison",0],["Harissa-mayo",0],["Moutarde au miel",0],["Tartare",0],["Tehina",0],["Houmous",0],["Sauce américaine",0],["Sauce maison",0],["Sans sauces",0]]},
 supplements:{title:"Suppléments",required:false,max:0,choices:[["Avocat",2],["Bacon",3],["Cheddar",2],["Œuf",2],["Oignons crispy",2],["Plaque Cheddar",6.5],["Steak",6.5],["Frites Maison",5],["Pain noir",2]]},
 accompagnement:{title:"Choix d'accompagnement",required:false,max:1,choices:[["Frites",0],["Riz",0],["Pâtes sauce tomate",0],["Salades",0]]},
 poulet:{title:"Choix du poulet",required:true,max:1,choices:[["Poulet crispy",0],["Poulet grillé",0],["Poulet pané",0],["Poulet parguit",0]]},
 viande:{title:"Choix de la viande",required:true,max:1,choices:[["Parguit",0],["Poulet pané",0],["Poulet crispy",0],["Poulet grillé",0],["Shawarma",0],["Merguez",0],["Kebab",0],["Steak haché",0],["Falafel",0]]},
 tender:{title:"Type de tender",required:false,max:1,choices:[["Classic Panure traditionnelle Maison",0],["Crispy Panure extra croustillante Maison",0],["Cheesy tradition maison, cœur cheddar",1.5]]},
 garniture:{title:"Retirer / garniture",required:false,max:5,choices:[["Nature",0],["Sans salade verte",0],["Sans tomate",0],["Sans oignons rouges",0],["Sans oignons confits",0],["Sans cornichons",0],["Sans cheddar",0],["Sans avocat",0],["Sans œuf",0],["Sans aubergines",0],["Sans choux blanc",0],["Sans choux rouge",0],["Sans houmous",0],["Sans téhina",0]]},
 boisson:{title:"Boisson",required:false,max:1,choices:[["Coca Cola",0],["Coca zéro",0],["Ice Tea pêche",0],["Oasis Tropical",0],["Sprite",0],["Perrier",0],["Évian",0],["Schweppes agrumes",0]]}
};

/* Correspondances de groupes réellement lues sur Wix.
   Les profils exacts prennent priorité; les autres restent sur le profil V0.4.3
   jusqu'à validation de leur ID Wix individuel. */
const EXACT={
 "Smash Burger":["cuisson","garniture","supplements"],
 "Double smash Burger":["cuisson","garniture","supplements"],
 "Cheese Burger":["cuisson","garniture","supplements"],
 "Bacon Burger":["cuisson","garniture","supplements"],
 "Chicken/Crispy Burger":["garniture","supplements"],
 "Sandwich Poulet grillé / Pané / Crispy":["pain","poulet","supplements"],
 "Sandwich steak haché":["pain","cuisson","garniture","supplements"],
 "Assiette Falafel Maison":["garniture","sauces","accompagnement"],
 "Tornado Potato":["supplements"],
 "Frites Maison":["sauces"],
 'Classic Burger':["cuisson", "garniture", "supplements"],
 'Sandwich Fait ton sandwich':["pain", "viande", "garniture", "sauces", "supplements"],
 'Assiette Shawarma':["cuisson", "garniture", "sauces", "accompagnement"],
 'Assiette Entrecôte':["cuisson", "sauces", "accompagnement"],
 'Assiette Poulet pané / crispy':["sauces", "accompagnement"],
 'MENU Classic Burger':["garniture", "boisson", "supplements"],
 'MENU SMASH Burger':["garniture", "boisson", "supplements"],
 'MENU Cheese Burger':["garniture", "boisson", "supplements"],
 'MENU Oriental Burger':["garniture", "boisson", "supplements"],
 "MENU Bechefaa's Burger":["garniture", "boisson", "supplements"],
 'Menu sandwich Merguez':["pain", "sauces", "garniture", "boisson", "supplements"],
 'Menu sandwich Entrecôte':["pain", "sauces", "garniture", "boisson", "supplements"],
 'MENU KIDS':["garniture", "boisson"],
 'Tender Chicken Maison 10 pièces':["tender", "sauces"],
 'Oignons rings 8 pièces':["supplements", "sauces"]
};
const WIX_GROUP_IDS={
 "Smash Burger":["b6c0c948-f34d-4d73-97fa-d1be347392a2","57d28489-33f5-4c99-bcb8-0f25188996e6","8c93a125-f155-4a5d-9612-d2eaee2910b5","d76054c5-a0e0-49c6-b722-e205c9cf00ec"],
 "Double smash Burger":["b6c0c948-f34d-4d73-97fa-d1be347392a2","57d28489-33f5-4c99-bcb8-0f25188996e6","8c93a125-f155-4a5d-9612-d2eaee2910b5"],
 "Cheese Burger":["b6c0c948-f34d-4d73-97fa-d1be347392a2","b999bd51-2557-44dd-b698-3a84e822a6c4","b4b442fc-b30c-476c-8016-c6f1549461a6"],
 "Bacon Burger":["b6c0c948-f34d-4d73-97fa-d1be347392a2","767954a4-2452-48e0-9cf5-ee82f644779a","487a8fc3-5dfc-4ccf-a2b8-63d5f4eeaa0c"],
 "Chicken/Crispy Burger":["9dcd3bcd-fe4a-407a-9b73-ecfd22555007","bdea0dcc-4cef-4daf-9c9c-23f8c0ce60a2"],
 "Sandwich Poulet grillé / Pané / Crispy":["84131005-29ae-44ed-941e-bda0af0b1b09","3f955d38-1153-49d3-9670-531e236dc035","a2c259fe-d269-4476-992d-e5935d94b73a"],
 "Tornado Potato":["ef40ec0c-6ee9-4bc7-9eb8-10c0cbba4329"],
 'Sandwich steak haché':["84131005-29ae-44ed-941e-bda0af0b1b09", "b6c0c948-f34d-4d73-97fa-d1be347392a2", "36fedc15-44bf-4b15-a1a9-51272f634e45", "a2c259fe-d269-4476-992d-e5935d94b73a"],
 'Classic Burger':["b6c0c948-f34d-4d73-97fa-d1be347392a2", "5b3910be-c94e-4d5e-98cf-d2ccf0626cc7", "00dd0aba-4fa2-4607-a68d-c24f7f82cad7", "d76054c5-a0e0-49c6-b722-e205c9cf00ec"],
 'Sandwich Fait ton sandwich':["88fc4aab-405f-4fba-afa3-ecb89b8758a8", "62f0bb59-f7fd-4660-a85b-0309c7d0883f", "b6c0c948-f34d-4d73-97fa-d1be347392a2", "7060ff2d-c722-4263-85a2-e5f0db8d9062", "7354c89e-e8f3-4ef4-b077-f76235279fff"],
 'Assiette Shawarma':["b6c0c948-f34d-4d73-97fa-d1be347392a2", "fbcd38ec-67cc-453a-8ebc-3675bddfd2ab", "595fe8b6-82c0-4fd1-bd27-e4718e769463", "7caed328-827a-42e7-8ece-e5c3b722dfa0"],
 'Assiette Entrecôte':["830bf309-4bd1-452b-8e5c-f03fc12ac788", "95165190-8d9f-4b25-9406-cfddb758e540", "0476bfe5-e4be-4e27-96c7-7c53f9be94ea"],
 'Assiette Poulet pané / crispy':["830bf309-4bd1-452b-8e5c-f03fc12ac788", "95165190-8d9f-4b25-9406-cfddb758e540"],
 'MENU Classic Burger':["0476bfe5-e4be-4e27-96c7-7c53f9be94ea", "c223160c-67b2-496b-b9a2-67a95c7bda90", "586fbdf4-99f7-4fb9-bf51-0686c5cce8ea"],
 'MENU SMASH Burger':["0476bfe5-e4be-4e27-96c7-7c53f9be94ea", "4c1731a6-80d1-46d1-81fb-c7b83a0feedd", "586fbdf4-99f7-4fb9-bf51-0686c5cce8ea"],
 'MENU Cheese Burger':["0476bfe5-e4be-4e27-96c7-7c53f9be94ea", "4c1731a6-80d1-46d1-81fb-c7b83a0feedd", "586fbdf4-99f7-4fb9-bf51-0686c5cce8ea"],
 'MENU Oriental Burger':["0476bfe5-e4be-4e27-96c7-7c53f9be94ea", "4c1731a6-80d1-46d1-81fb-c7b83a0feedd", "586fbdf4-99f7-4fb9-bf51-0686c5cce8ea"],
 "MENU Bechefaa's Burger":["0476bfe5-e4be-4e27-96c7-7c53f9be94ea", "c223160c-67b2-496b-b9a2-67a95c7bda90", "586fbdf4-99f7-4fb9-bf51-0686c5cce8ea"],
 'Menu sandwich Merguez':["84131005-29ae-44ed-941e-bda0af0b1b09", "95165190-8d9f-4b25-9406-cfddb758e540", "0476bfe5-e4be-4e27-96c7-7c53f9be94ea", "c223160c-67b2-496b-b9a2-67a95c7bda90", "586fbdf4-99f7-4fb9-bf51-0686c5cce8ea"],
 'Menu sandwich Entrecôte':["84131005-29ae-44ed-941e-bda0af0b1b09", "95165190-8d9f-4b25-9406-cfddb758e540", "0476bfe5-e4be-4e27-96c7-7c53f9be94ea", "c223160c-67b2-496b-b9a2-67a95c7bda90", "586fbdf4-99f7-4fb9-bf51-0686c5cce8ea"],
 'MENU KIDS':["0476bfe5-e4be-4e27-96c7-7c53f9be94ea", "c223160c-67b2-496b-b9a2-67a95c7bda90"],
 'Tender Chicken Maison 10 pièces':["fd2d1e58-ff68-4353-8472-6658a6322bf2", "95165190-8d9f-4b25-9406-cfddb758e540"],
 'Oignons rings 8 pièces':["b146bf0e-e648-4879-bd8b-acbfe33d0edc", "95165190-8d9f-4b25-9406-cfddb758e540"]
};
function norm(s){return (s||"").normalize("NFD").replace(/[\u0300-\u036f]/g,"").toLowerCase().replace(/\s+/g," ").trim()}
function exactKey(p){
 const n=norm(p.name);
 return Object.keys(EXACT).find(k=>norm(k)===n) ||
        (n.includes("sandwich poulet") ? "Sandwich Poulet grillé / Pané / Crispy" :
         n.includes("fait ton sandwich") ? "Sandwich Fait ton sandwich" : null);
}
function profile(p){
 let ek=exactKey(p);
 if(ek)return EXACT[ek];
 let a=[],n=p.name.toLowerCase();
 if(p.cat==="Burger"){if(!n.includes("fish")&&!n.includes("chicken"))a.push("cuisson");a.push("garniture","supplements")}
 if(p.cat==="Sandwich"){if(!n.includes("hot-dog"))a.push("pain");a.push("garniture","sauces","supplements")}
 if(p.cat==="Assiette"){if(["entrecôte","merguez","mochy","shawarma","double steak"].some(x=>n.includes(x)))a.push("cuisson");a.push("sauces","accompagnement")}
 if(n.includes("poulet")||n.includes("chicken/crispy"))a.push("poulet");
 if(n.includes("pita pané")||n.includes("fait ton sandwich"))a.push("viande");
 if(n.includes("tender chicken"))a.push("tender");
 if(p.cat==="Nos formules MIDI"&&!n.includes("mochy"))a.push("boisson");
 if(n.includes("menu kids")||n.includes("formule enfant"))a.push("boisson");
 return [...new Set(a)];
}
function rc(){$("cats").innerHTML=window.CATEGORIES.map(c=>`<button data-c="${encodeURIComponent(c)}" class="${c===cat?"active":""}">${c}</button>`).join("");$("cats").querySelectorAll("button").forEach(b=>b.onclick=()=>{cat=decodeURIComponent(b.dataset.c);rc();rp()})}
function rp(){let l=window.PRODUCTS.filter(p=>p.cat===cat);$("products").innerHTML=l.map(p=>`<button class="product" data-id="${p.id}"><img src="${p.image}" alt=""><div class="pbody"><div class="pname">${p.name}</div><div class="price">${euro(price(p.price))}</div></div></button>`).join("");$("products").querySelectorAll(".product").forEach(b=>b.onclick=()=>openProduct(+b.dataset.id))}
function openProduct(id){
 current=window.PRODUCTS.find(x=>x.id===id); selections={}; const prof=profile(current);
 if(!prof.length){addConfiguredDirect();return}
 $("optTitle").textContent=current.name;let ek=exactKey(current),ids=ek?WIX_GROUP_IDS[ek]:null;
 $("optBase").textContent=`${ch} · prix de base ${euro(price(current.price))}${ids?` · liaison Wix exacte (${ids.length} groupe${ids.length>1?"s":""})`:" · profil local en attente de liaison exacte"}`;
 $("optionGroups").innerHTML=prof.map(k=>renderGroup(k)).join("");
 $("optionGroups").querySelectorAll(".optchoice").forEach(b=>b.onclick=()=>toggleOption(b));
 $("optionModal").classList.remove("hidden");updateOptionTotal()
}
function renderGroup(k){
 const g=GROUPS[k],meta=[g.required?"Obligatoire":"Facultatif",g.max?`max. ${g.max}`:"plusieurs choix"].join(" · ");
 return `<div class="optgroup"><h3>${g.title}</h3><div class="optmeta">${meta}</div><div class="optchoices">${g.choices.map(([n,p])=>`<button class="optchoice" data-g="${k}" data-n="${encodeURIComponent(n)}" data-p="${p}">${n}${p?` +${euro(price(p))}`:""}</button>`).join("")}</div></div>`
}
function toggleOption(b){
 const k=b.dataset.g,g=GROUPS[k],name=decodeURIComponent(b.dataset.n),p=+b.dataset.p; selections[k]=selections[k]||[];
 let i=selections[k].findIndex(x=>x.name===name);
 if(i>=0){selections[k].splice(i,1);b.classList.remove("selected")}
 else{
   if(g.max===1){selections[k]=[];document.querySelectorAll(`[data-g="${k}"]`).forEach(x=>x.classList.remove("selected"))}
   else if(g.max&&selections[k].length>=g.max){alert(`Maximum ${g.max} choix.`);return}
   selections[k].push({name,price:p});b.classList.add("selected")
 }
 updateOptionTotal()
}
function optionExtra(){return Object.values(selections).flat().reduce((s,x)=>s+price(x.price),0)}
function updateOptionTotal(){$("optTotal").textContent=euro(price(current.price)+optionExtra())}
function validateRequired(){for(const k of profile(current)){if(GROUPS[k].required&&!(selections[k]?.length)){alert(`Choisissez : ${GROUPS[k].title}`);return false}}return true}
function optionText(o){return Object.entries(o||{}).filter(([,v])=>v.length).map(([k,v])=>`${GROUPS[k].title}: ${v.map(x=>x.name).join(", ")}`).join(" · ")}
function addConfiguredDirect(){let u=price(current.price),x=cart.find(i=>i.id===current.id&&!i.optionsText&&i.unit===u);x?x.qty++:cart.push({lineId:Date.now()+Math.random(),id:current.id,name:current.name,unit:u,qty:1,options:{},optionsText:""});rCart()}
function addConfigured(){if(!validateRequired())return;let opts=JSON.parse(JSON.stringify(selections)),txt=optionText(opts),u=price(current.price)+optionExtra(),ek=exactKey(current);
 cart.push({lineId:Date.now()+Math.random(),id:current.id,name:current.name,unit:u,qty:1,options:opts,optionsText:txt,wixModifierGroupIds:ek?(WIX_GROUP_IDS[ek]||[]):[]});$("optionModal").classList.add("hidden");rCart()}
function rCart(){$("cartItems").innerHTML=cart.length?cart.map(x=>`<div class="line"><div class="lineTop"><span><b>${x.qty}×</b> ${x.name}</span><b>${euro(x.qty*x.unit)}</b></div>${x.optionsText?`<div class="lineopts">${x.optionsText}</div>`:""}<div class="actions"><button data-dec="${x.lineId}">−</button><button data-inc="${x.lineId}">＋</button><button class="danger" data-del="${x.lineId}">Supprimer</button></div></div>`).join(""):'<div class="empty">Commande vide</div>';$("total").textContent=euro(cart.reduce((s,x)=>s+x.qty*x.unit,0));document.querySelectorAll("[data-inc]").forEach(b=>b.onclick=()=>{let x=cart.find(x=>x.lineId==b.dataset.inc);x.qty++;rCart()});document.querySelectorAll("[data-dec]").forEach(b=>b.onclick=()=>{let x=cart.find(x=>x.lineId==b.dataset.dec);if(--x.qty<=0)cart=cart.filter(i=>i.lineId!=b.dataset.dec);rCart()});document.querySelectorAll("[data-del]").forEach(b=>b.onclick=()=>{cart=cart.filter(i=>i.lineId!=b.dataset.del);rCart()})}
function saveC(){localStorage.setItem("b_clients043",JSON.stringify(clients))}function saveO(){localStorage.setItem("b_orders043",JSON.stringify(orders))}
function find(q){q=q.toLowerCase().replace(/\s/g,"");return clients.filter(c=>c.name.toLowerCase().includes(q)||c.phone.replace(/\s/g,"").includes(q))}
$("cust").oninput=()=>{let q=$("cust").value.trim();$("matches").innerHTML=q?find(q).slice(0,5).map(c=>`<div class="match" data-cid="${c.id}"><b>${c.name}</b><br>${c.phone}</div>`).join(""):"";document.querySelectorAll("[data-cid]").forEach(e=>e.onclick=()=>pick(+e.dataset.cid))};function pick(id){sel=clients.find(c=>c.id===id);$("selected").classList.remove("hidden");$("selected").innerHTML=`<b>${sel.name}</b><br>${sel.phone}${sel.address?"<br>"+sel.address:""}`;$("matches").innerHTML="";$("cust").value=""}
function rClients(q=""){let l=q?find(q):clients;$("clientList").innerHTML=l.map(c=>`<div class="clientrow" data-id="${c.id}"><b>${c.name}</b><br>${c.phone}</div>`).join("");document.querySelectorAll(".clientrow").forEach(e=>e.onclick=()=>detail(+e.dataset.id))}
function detail(id){let c=clients.find(x=>x.id===id),h=orders.filter(o=>o.customerId===id);$("clientDetail").innerHTML=`<h2>${c.name}</h2><p>${c.phone}</p><p>${c.address||""}</p><h3>Historique (${h.length})</h3>${h.map(o=>`<div class="line">#${o.num} · ${euro(o.total)}</div>`).join("")||"Aucune commande"}`}
function move(id){let o=orders.find(x=>x.id===id);o.status=o.status==="À préparer"?"En préparation":o.status==="En préparation"?"Prête":"Terminée";saveO();boards()}
function card(o){let n=o.status==="À préparer"?"DÉMARRER":o.status==="En préparation"?"PRÊTE":o.status==="Prête"?"TERMINER":"";return `<div class="order"><h3>#${o.num} · ${o.customer}</h3><span class="badge">${o.source}</span> <span class="badge">${o.payment}</span><ul>${o.items.map(i=>`<li><b>${i.qty}× ${i.name}</b>${i.optionsText?`<br><small>${i.optionsText}</small>`:""}</li>`).join("")}</ul>${n?`<button data-m="${o.id}">${n}</button>`:""}</div>`}
function boards(){let ss=["À préparer","En préparation","Prête"],h=ss.map(s=>`<div class="col"><h2>${s}</h2>${orders.filter(o=>o.status===s).map(card).join("")||'<div class="empty">Aucune</div>'}</div>`).join("");$("ordersBoard").innerHTML=h;$("kitchenBoard").innerHTML=h;document.querySelectorAll("[data-m]").forEach(b=>b.onclick=()=>move(+b.dataset.m))}
$("addConfigured").onclick=addConfigured;$("closeOptions").onclick=()=>$("optionModal").classList.add("hidden");
$("validate").onclick=()=>{if(!cart.length)return alert("Ajoutez un produit.");let total=cart.reduce((s,x)=>s+x.qty*x.unit,0),o={id:Date.now(),num:1000+orders.length+1,customerId:sel?.id||null,customer:sel?.name||"Client comptoir",source:ch,payment:ch==="WIX"?"PAYÉ EN LIGNE / STRIPE":ch==="CAISSE"?"À ENCAISSER":"PAYÉ PLATEFORME",status:"À préparer",items:cart.map(x=>({...x})),total};orders.unshift(o);saveO();cart=[];sel=null;$("selected").classList.add("hidden");rCart();boards();alert("Commande envoyée en cuisine.")};$("clear").onclick=()=>{if(cart.length&&confirm("Vider toute la commande ?")){cart=[];rCart()}};$("fullscreen").onclick=()=>document.documentElement.requestFullscreen?.();
document.querySelectorAll(".channel").forEach(b=>b.onclick=()=>{document.querySelectorAll(".channel").forEach(x=>x.classList.remove("active"));b.classList.add("active");ch=b.dataset.ch;rp()});document.querySelectorAll(".nav").forEach(b=>b.onclick=()=>{document.querySelectorAll(".nav").forEach(x=>x.classList.remove("active"));b.classList.add("active");document.querySelectorAll(".view").forEach(v=>v.classList.add("hidden"));$(b.dataset.view).classList.remove("hidden");if(b.dataset.view==="clients")rClients();if(["orders","kitchen"].includes(b.dataset.view))boards()});
$("newClient").onclick=()=>$("clientModal").classList.remove("hidden");$("closeClient").onclick=()=>$("clientModal").classList.add("hidden");$("saveClient").onclick=()=>{let n=$("cn").value.trim(),p=$("cp").value.trim();if(!n||!p)return alert("Nom et téléphone obligatoires.");let c={id:Date.now(),name:n,phone:p,address:$("ca").value.trim()};clients.unshift(c);saveC();$("clientModal").classList.add("hidden");rClients();pick(c.id)};$("clientFilter").oninput=e=>rClients(e.target.value);rc();rp();rCart();rClients();boards();if("serviceWorker" in navigator)navigator.serviceWorker.register("./sw.js").catch(()=>{});
window.addEventListener("offline",()=>document.body.classList.add("offline"));
window.addEventListener("online",()=>document.body.classList.remove("offline"));
if(!navigator.onLine)document.body.classList.add("offline")
});