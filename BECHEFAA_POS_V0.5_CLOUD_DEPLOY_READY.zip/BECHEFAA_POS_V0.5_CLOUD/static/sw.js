const CORE="bechefaa-v044-core",IMG="bechefaa-v044-images";
const CORE_FILES=["./","./index.html","./style.css","./app.js","./manifest.webmanifest"];
self.addEventListener("install",e=>e.waitUntil(caches.open(CORE).then(c=>c.addAll(CORE_FILES))));
self.addEventListener("activate",e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>!([CORE,IMG].includes(k))).map(k=>caches.delete(k))))));
self.addEventListener("fetch",e=>{
 const u=new URL(e.request.url);
 if(u.hostname==="static.wixstatic.com"){
   e.respondWith(caches.open(IMG).then(async c=>{
     const hit=await c.match(e.request);
     if(hit)return hit;
     try{const r=await fetch(e.request); if(r.ok)c.put(e.request,r.clone()); return r}
     catch(err){return hit||Response.error()}
   })); return;
 }
 e.respondWith(caches.match(e.request).then(async hit=>{
   try{const r=await fetch(e.request); if(r.ok&&e.request.method==="GET"){const c=await caches.open(CORE);c.put(e.request,r.clone())}return r}
   catch(err){return hit||Response.error()}
 }));
});