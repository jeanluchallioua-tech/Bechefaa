
from flask import Flask, jsonify, request, send_from_directory
import sqlite3, json, os, time
from pathlib import Path

BASE = Path(__file__).resolve().parent
DB = Path(os.getenv("BECHEFAA_DB", BASE / "bechefaa.db"))
app = Flask(__name__, static_folder="static", static_url_path="")

def conn():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c

def init_db():
    with conn() as c:
        c.execute("""CREATE TABLE IF NOT EXISTS orders(
            id TEXT PRIMARY KEY,
            num INTEGER,
            customer_id TEXT,
            customer TEXT,
            source TEXT,
            payment TEXT,
            status TEXT,
            total REAL,
            items_json TEXT NOT NULL,
            created_at INTEGER NOT NULL,
            updated_at INTEGER NOT NULL
        )""")
        c.execute("""CREATE TABLE IF NOT EXISTS clients(
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            phone TEXT NOT NULL,
            address TEXT DEFAULT '',
            updated_at INTEGER NOT NULL
        )""")

def order_dict(r):
    return {
        "id": r["id"], "num": r["num"], "customerId": r["customer_id"],
        "customer": r["customer"], "source": r["source"], "payment": r["payment"],
        "status": r["status"], "total": r["total"],
        "items": json.loads(r["items_json"] or "[]"),
        "createdAt": r["created_at"], "updatedAt": r["updated_at"]
    }

@app.get("/api/health")
def health():
    return {"ok": True, "service": "BECHEFAA POS V0.5 Cloud"}

@app.get("/api/orders")
def get_orders():
    with conn() as c:
        rows = c.execute("SELECT * FROM orders ORDER BY created_at DESC").fetchall()
    return jsonify([order_dict(r) for r in rows])

@app.post("/api/orders")
def post_order():
    o = request.get_json(force=True)
    now = int(time.time()*1000)
    oid = str(o.get("id") or now)
    items = o.get("items") or []
    for item in items:
        item.setdefault("prepared", False)
    with conn() as c:
        c.execute("""INSERT INTO orders(id,num,customer_id,customer,source,payment,status,total,items_json,created_at,updated_at)
          VALUES(?,?,?,?,?,?,?,?,?,?,?)
          ON CONFLICT(id) DO UPDATE SET
            num=excluded.num, customer_id=excluded.customer_id, customer=excluded.customer,
            source=excluded.source, payment=excluded.payment, status=excluded.status,
            total=excluded.total, items_json=excluded.items_json, updated_at=excluded.updated_at""",
          (oid, o.get("num"), str(o.get("customerId") or ""), o.get("customer","Client comptoir"),
           o.get("source","CAISSE"), o.get("payment","À ENCAISSER"), o.get("status","À préparer"),
           float(o.get("total") or 0), json.dumps(items, ensure_ascii=False), now, now))
    return jsonify({"ok":True,"id":oid})

@app.patch("/api/orders/<oid>")
def patch_order(oid):
    data = request.get_json(force=True)
    allowed = {"status","customer","payment","source"}
    fields = {k:v for k,v in data.items() if k in allowed}
    if not fields: return jsonify({"ok":True})
    fields["updated_at"] = int(time.time()*1000)
    sql = "UPDATE orders SET " + ", ".join(f"{k}=?" for k in fields) + " WHERE id=?"
    with conn() as c:
        c.execute(sql, [*fields.values(), oid])
    return jsonify({"ok":True})

@app.patch("/api/orders/<oid>/items/<int:index>")
def patch_item(oid, index):
    data = request.get_json(force=True)
    with conn() as c:
        r = c.execute("SELECT items_json FROM orders WHERE id=?", (oid,)).fetchone()
        if not r: return jsonify({"error":"order not found"}),404
        items = json.loads(r["items_json"] or "[]")
        if index < 0 or index >= len(items): return jsonify({"error":"item not found"}),404
        items[index]["prepared"] = bool(data.get("prepared"))
        c.execute("UPDATE orders SET items_json=?, updated_at=? WHERE id=?",
                  (json.dumps(items,ensure_ascii=False), int(time.time()*1000), oid))
    return jsonify({"ok":True})

@app.get("/api/clients")
def get_clients():
    with conn() as c:
        rows = c.execute("SELECT * FROM clients ORDER BY name").fetchall()
    return jsonify([{"id":r["id"],"name":r["name"],"phone":r["phone"],"address":r["address"]} for r in rows])

@app.post("/api/clients")
def post_client():
    x = request.get_json(force=True)
    cid = str(x.get("id") or int(time.time()*1000))
    with conn() as c:
        c.execute("""INSERT INTO clients(id,name,phone,address,updated_at) VALUES(?,?,?,?,?)
          ON CONFLICT(id) DO UPDATE SET name=excluded.name,phone=excluded.phone,address=excluded.address,updated_at=excluded.updated_at""",
          (cid,x.get("name",""),x.get("phone",""),x.get("address",""),int(time.time()*1000)))
    return jsonify({"ok":True,"id":cid})

@app.get("/")
@app.get("/caisse")
@app.get("/salle")
@app.get("/cuisine")
def frontend():
    return send_from_directory(app.static_folder, "index.html")

@app.get("/<path:path>")
def static_files(path):
    return send_from_directory(app.static_folder, path)

if __name__ == "__main__":
    init_db()
    port = int(os.getenv("PORT","5000"))
    app.run(host="0.0.0.0", port=port)
else:
    init_db()
